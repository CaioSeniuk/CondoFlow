# Template Method — Relatórios financeiros

O algoritmo fixo de `FinancialReportTemplate` é:

1. verificar permissão de manager;
2. buscar dados do período;
3. calcular os indicadores;
4. formatar a resposta.

As subclasses são `CategoryExpenseReport` e `BudgetVsActualReport`.

O repositório é recebido por injeção para permitir conectar as classes às
tabelas/repositórios financeiros já existentes no projeto.
