import { AuthenticatedUser } from '../auth/authenticated-user.interface';
import {
  BudgetVsActualReport,
  CategoryExpenseReport,
  FinancialReportRepository,
  FinancialReportRequest,
  FinancialReportTemplate,
} from './templates';

export type FinancialReportType = 'category-expense' | 'budget-vs-actual';

export class FinanceService {
  private readonly reports: Record<FinancialReportType, FinancialReportTemplate>;

  constructor(repo: FinancialReportRepository) {
    this.reports = {
      'category-expense': new CategoryExpenseReport(repo),
      'budget-vs-actual': new BudgetVsActualReport(repo),
    };
  }

  generateReport(
    type: FinancialReportType,
    request: FinancialReportRequest,
    actor: AuthenticatedUser,
  ) {
    return this.reports[type].generate(request, actor);
  }
}
