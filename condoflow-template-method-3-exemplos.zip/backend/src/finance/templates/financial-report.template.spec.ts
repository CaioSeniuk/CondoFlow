import { UserRole } from '@prisma/client';
import { AuthenticatedUser } from '../../auth/authenticated-user.interface';
import {
  BudgetVsActualReport,
  CategoryExpenseReport,
  ExpenseRecord,
  FinancialReportRepository,
} from './index';

const manager = {
  id: 2n,
  username: 'manager',
  role: UserRole.manager,
  block: '',
  apartment: '',
} as AuthenticatedUser;

const resident = {
  id: 1n,
  username: 'resident',
  role: UserRole.resident,
  block: 'A',
  apartment: '101',
} as AuthenticatedUser;

const expenses: ExpenseRecord[] = [
  { id: 1n, category: 'Limpeza', description: 'Material', amount: 100, date: new Date('2026-09-01') },
  { id: 2n, category: 'Limpeza', description: 'Produto', amount: 50, date: new Date('2026-09-02') },
  { id: 3n, category: 'Manutenção', description: 'Peça', amount: 200, date: new Date('2026-09-03') },
];

describe('FinancialReportTemplate', () => {
  it('keeps the common algorithm and calculates expenses by category', async () => {
    const repo = {
      hasManagerPermission: jest.fn().mockReturnValue(true),
      fetchExpenses: jest.fn().mockResolvedValue(expenses),
    } as unknown as FinancialReportRepository;

    const report = await new CategoryExpenseReport(repo).generate(
      { startDate: new Date('2026-09-01'), endDate: new Date('2026-09-30') },
      manager,
    );

    expect(repo.hasManagerPermission).toHaveBeenCalledWith(manager);
    expect(repo.fetchExpenses).toHaveBeenCalled();
    expect(report.title).toBe('Despesas por categoria');
    expect(report.summary).toMatchObject({
      total: 350,
      expenseCount: 3,
      byCategory: { Limpeza: 150, Manutenção: 200 },
    });
  });

  it('uses the same template but adds budget-vs-actual calculation', async () => {
    const repo = {
      hasManagerPermission: jest.fn().mockReturnValue(true),
      fetchExpenses: jest.fn().mockResolvedValue(expenses),
      fetchBudgets: jest.fn().mockResolvedValue([
        { category: 'Limpeza', amount: 200 },
        { category: 'Manutenção', amount: 150 },
      ]),
    } as unknown as FinancialReportRepository;

    const report = await new BudgetVsActualReport(repo).generate(
      { startDate: new Date('2026-09-01'), endDate: new Date('2026-09-30') },
      manager,
    );

    expect(report.title).toBe('Orçado x realizado');
    expect(report.summary).toMatchObject({
      budgetTotal: 350,
      actualTotal: 350,
    });
    expect(report.lines[0]).toContain('Limpeza');
  });

  it('blocks non-managers before querying financial data', async () => {
    const repo = {
      hasManagerPermission: jest.fn().mockReturnValue(false),
      fetchExpenses: jest.fn(),
    } as unknown as FinancialReportRepository;

    await expect(
      new CategoryExpenseReport(repo).generate(
        { startDate: new Date('2026-09-01'), endDate: new Date('2026-09-30') },
        resident,
      ),
    ).rejects.toThrow('Only managers can generate financial reports');

    expect(repo.fetchExpenses).not.toHaveBeenCalled();
  });
});
