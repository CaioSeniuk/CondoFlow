import { UserRole } from '@prisma/client';
import { AuthenticatedUser } from '../../auth/authenticated-user.interface';
import {
  AnnouncementRepository,
  AnnouncementVisibilityChain,
  StandardAnnouncementPublisher,
  UrgentAnnouncementPublisher,
} from './index';

const manager = {
  id: 2n,
  username: 'manager',
  role: UserRole.manager,
  block: '',
  apartment: '',
} as AuthenticatedUser;

function makeDependencies() {
  const visibilityChain = {
    validate: jest.fn().mockResolvedValue(undefined),
  } as unknown as AnnouncementVisibilityChain;

  const repo = {
    save: jest.fn().mockImplementation(async (data) => ({
      id: 10n,
      ...data,
    })),
    configureReadTracking: jest.fn().mockResolvedValue(undefined),
  } as unknown as AnnouncementRepository;

  return { visibilityChain, repo };
}

describe('AnnouncementPublisherTemplate', () => {
  it('runs the common sequence and formats a standard announcement', async () => {
    const { visibilityChain, repo } = makeDependencies();

    const result = await new StandardAnnouncementPublisher(repo, visibilityChain).publish(
      {
        title: '  Manutenção  ',
        body: '  A água será desligada. ',
        audience: 'residents',
      },
      manager,
    );

    expect(visibilityChain.validate).toHaveBeenCalled();
    expect(repo.save).toHaveBeenCalledWith(
      expect.objectContaining({
        title: 'Manutenção',
        body: 'A água será desligada.',
        urgent: false,
        createdById: manager.id,
      }),
    );
    expect(repo.configureReadTracking).toHaveBeenCalledWith(10n);
    expect(result.urgent).toBe(false);
  });

  it('reuses the template but formats urgent announcements differently', async () => {
    const { visibilityChain, repo } = makeDependencies();

    const result = await new UrgentAnnouncementPublisher(repo, visibilityChain).publish(
      {
        title: 'Interrupção de energia',
        body: 'A energia será interrompida às 22h.',
        audience: 'all',
      },
      manager,
    );

    expect(result.title).toBe('⚠ INTERRUPÇÃO DE ENERGIA');
    expect(result.body).toContain('URGENTE:');
    expect(result.urgent).toBe(true);
    expect(repo.configureReadTracking).toHaveBeenCalledWith(10n);
  });

  it('does not save when the visibility chain rejects the audience', async () => {
    const { visibilityChain, repo } = makeDependencies();
    (visibilityChain.validate as jest.Mock).mockRejectedValue(
      new Error('Audience is not allowed'),
    );

    await expect(
      new StandardAnnouncementPublisher(repo, visibilityChain).publish(
        {
          title: 'Aviso',
          body: 'Mensagem',
          audience: 'managers',
        },
        manager,
      ),
    ).rejects.toThrow('Audience is not allowed');

    expect(repo.save).not.toHaveBeenCalled();
  });
});
