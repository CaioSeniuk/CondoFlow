import { AuthenticatedUser } from '../auth/authenticated-user.interface';
import {
  AnnouncementDraft,
  AnnouncementRepository,
  AnnouncementVisibilityChain,
  AnnouncementPublisherTemplate,
} from './templates';
import { StandardAnnouncementPublisher } from './templates/standard-announcement-publisher';
import { UrgentAnnouncementPublisher } from './templates/urgent-announcement-publisher';

export type AnnouncementType = 'standard' | 'urgent';

export class AnnouncementsService {
  private readonly publishers: Record<AnnouncementType, AnnouncementPublisherTemplate>;

  constructor(
    repo: AnnouncementRepository,
    visibilityChain: AnnouncementVisibilityChain,
  ) {
    this.publishers = {
      standard: new StandardAnnouncementPublisher(repo, visibilityChain),
      urgent: new UrgentAnnouncementPublisher(repo, visibilityChain),
    };
  }

  publish(
    type: AnnouncementType,
    draft: AnnouncementDraft,
    actor: AuthenticatedUser,
  ) {
    return this.publishers[type].publish(draft, actor);
  }
}
