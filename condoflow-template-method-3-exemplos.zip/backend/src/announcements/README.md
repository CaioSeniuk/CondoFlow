# Template Method — Comunicados

O algoritmo de publicação fica em `AnnouncementPublisherTemplate`:

1. validar a segmentação;
2. reutilizar a `AnnouncementVisibilityChain`;
3. formatar a mensagem;
4. salvar;
5. configurar o rastreamento de leitura.

As subclasses são `StandardAnnouncementPublisher` e `UrgentAnnouncementPublisher`.

A Chain de visibilidade é recebida por injeção (`AnnouncementVisibilityChain`) para
que a implementação já existente no projeto possa ser reutilizada sem duplicar
as regras de acesso.
