import { ForbiddenException } from '@nestjs/common';
import { Ticket, TicketStatus, TicketUrgency, UserRole } from '@prisma/client';
import { AuthenticatedUser } from '../../auth/authenticated-user.interface';
import { StatusHistoryRepository, TicketsRepository } from '../tickets.repository';
import { buildStatusTransitionChain } from '../status-transition.chain';
import { InvalidStatusTransitionError } from '../tickets.errors';
import { ResidentTicketActionProcessor } from './resident-ticket-action.processor';
import { ManagerTicketActionProcessor } from './manager-ticket-action.processor';
import { ProviderTicketActionProcessor } from './provider-ticket-action.processor';

const resident: AuthenticatedUser = {
  id: 1n,
  username: 'resident1',
  role: UserRole.resident,
  block: 'A',
  apartment: '101',
};
const manager: AuthenticatedUser = {
  id: 2n,
  username: 'manager1',
  role: UserRole.manager,
  block: '',
  apartment: '',
};
const provider: AuthenticatedUser = {
  id: 3n,
  username: 'provider1',
  role: UserRole.provider,
  block: '',
  apartment: '',
};

function ticket(status: TicketStatus, providerId: bigint | null = null): Ticket {
  return {
    id: 5n,
    createdAt: new Date(),
    updatedAt: new Date(),
    createdById: 1n,
    updatedById: null,
    residentId: 1n,
    category: 'Plumbing',
    location: 'Bathroom',
    description: 'Leaking pipe',
    photo: null,
    urgency: TicketUrgency.low,
    status,
    providerId,
  };
}

function makeRepo(overrides: Partial<TicketsRepository> = {}): TicketsRepository {
  return overrides as TicketsRepository;
}

describe('ResidentTicketActionProcessor', () => {
  it('lets the resident edit the ticket while it is still open', async () => {
    const found = ticket(TicketStatus.open);
    const update = jest.fn().mockResolvedValue({ ...found, description: 'Updated' });
    const repo = makeRepo({
      findByIdForResident: jest.fn().mockResolvedValue(found),
      update,
    });
    const historyCreate = jest.fn();
    const processor = new ResidentTicketActionProcessor(repo, {
      create: historyCreate,
    } as unknown as StatusHistoryRepository);

    await processor.executeAction(5n, resident, { description: 'Updated' });

    expect(repo.findByIdForResident).toHaveBeenCalledWith(5n, resident.id);
    expect(update).toHaveBeenCalledWith(
      5n,
      expect.objectContaining({ description: 'Updated', updatedById: resident.id }),
    );
    expect(historyCreate).not.toHaveBeenCalled();
  });

  it('rejects editing once the ticket left the open status', async () => {
    const repo = makeRepo({
      findByIdForResident: jest.fn().mockResolvedValue(ticket(TicketStatus.under_review)),
    });
    const processor = new ResidentTicketActionProcessor(
      repo,
      {} as StatusHistoryRepository,
    );

    await expect(
      processor.executeAction(5n, resident, { description: 'Updated' }),
    ).rejects.toThrow(ForbiddenException);
  });
});

describe('ManagerTicketActionProcessor', () => {
  function makeProcessor(repo: TicketsRepository, historyCreate = jest.fn()) {
    return {
      processor: new ManagerTicketActionProcessor(
        repo,
        { create: historyCreate } as unknown as StatusHistoryRepository,
        buildStatusTransitionChain(),
      ),
      historyCreate,
    };
  }

  it('validates an open ticket, moving it to under_review', async () => {
    const found = ticket(TicketStatus.open);
    const update = jest.fn().mockResolvedValue({ ...found, status: TicketStatus.under_review });
    const repo = makeRepo({ findById: jest.fn().mockResolvedValue(found), update });
    const { processor, historyCreate } = makeProcessor(repo);

    await processor.executeAction(5n, manager, { note: 'Checked in person' });

    expect(update).toHaveBeenCalledWith(
      5n,
      expect.objectContaining({ status: TicketStatus.under_review }),
    );
    expect(historyCreate).toHaveBeenCalledWith(
      5n,
      TicketStatus.under_review,
      manager.id,
      'Checked in person',
    );
  });

  it('assigns a provider without going through the status transition chain', async () => {
    const found = ticket(TicketStatus.under_review);
    const update = jest.fn().mockResolvedValue({ ...found, providerId: 9n });
    const repo = makeRepo({ findById: jest.fn().mockResolvedValue(found), update });
    const { processor, historyCreate } = makeProcessor(repo);

    await processor.executeAction(5n, manager, { providerId: 9 });

    expect(update).toHaveBeenCalledWith(
      5n,
      expect.objectContaining({ providerId: 9n, status: TicketStatus.provider_assigned }),
    );
    expect(historyCreate).toHaveBeenCalledWith(
      5n,
      TicketStatus.provider_assigned,
      manager.id,
      'Provider assigned',
    );
  });

  it('reuses the status transition chain, so a resolved ticket cannot be re-validated', async () => {
    const repo = makeRepo({ findById: jest.fn().mockResolvedValue(ticket(TicketStatus.resolved)) });
    const { processor } = makeProcessor(repo);

    await expect(
      processor.executeAction(5n, manager, { status: TicketStatus.under_review }),
    ).rejects.toThrow(InvalidStatusTransitionError);
  });
});

describe('ProviderTicketActionProcessor', () => {
  it('lets the assigned provider move an assigned ticket to in_progress', async () => {
    const found = ticket(TicketStatus.provider_assigned, 3n);
    const update = jest.fn().mockResolvedValue({ ...found, status: TicketStatus.in_progress });
    const historyCreate = jest.fn();
    const repo = makeRepo({
      findByIdForProviderUser: jest.fn().mockResolvedValue(found),
      update,
    });
    const processor = new ProviderTicketActionProcessor(
      repo,
      { create: historyCreate } as unknown as StatusHistoryRepository,
      buildStatusTransitionChain(),
    );

    await processor.executeAction(5n, provider, { status: TicketStatus.in_progress });

    expect(repo.findByIdForProviderUser).toHaveBeenCalledWith(5n, provider.id);
    expect(update).toHaveBeenCalledWith(
      5n,
      expect.objectContaining({ status: TicketStatus.in_progress }),
    );
    expect(historyCreate).toHaveBeenCalledWith(5n, TicketStatus.in_progress, provider.id, '');
  });

  it('rejects statuses outside in_progress/resolved', async () => {
    const repo = makeRepo({
      findByIdForProviderUser: jest.fn().mockResolvedValue(ticket(TicketStatus.provider_assigned, 3n)),
    });
    const processor = new ProviderTicketActionProcessor(
      repo,
      {} as StatusHistoryRepository,
      buildStatusTransitionChain(),
    );

    await expect(
      processor.executeAction(5n, provider, { status: TicketStatus.under_review }),
    ).rejects.toThrow(ForbiddenException);
  });

  it('reuses the status transition chain, so moving to in_progress without a provider still fails', async () => {
    const repo = makeRepo({
      findByIdForProviderUser: jest.fn().mockResolvedValue(ticket(TicketStatus.under_review)),
    });
    const processor = new ProviderTicketActionProcessor(
      repo,
      {} as StatusHistoryRepository,
      buildStatusTransitionChain(),
    );

    await expect(
      processor.executeAction(5n, provider, { status: TicketStatus.in_progress }),
    ).rejects.toThrow(InvalidStatusTransitionError);
  });
});
