# CondoFlow — Template Method (3 exemplos)

Este ZIP preserva a implementação existente de **chamados (tickets)** e adiciona os
dois exemplos restantes solicitados pela disciplina.

## 1. Chamados
Implementação existente em `tickets/processors/`:
- `TicketActionTemplate`
- `ResidentTicketActionProcessor`
- `ManagerTicketActionProcessor`
- `ProviderTicketActionProcessor`

Esqueleto: carregar no escopo -> aplicar regra específica -> persistir/auditar ->
registrar histórico -> hook de notificação.

## 2. Relatórios financeiros
Arquivos em `finance/templates/`:
- `FinancialReportTemplate`
- `CategoryExpenseReport`
- `BudgetVsActualReport`

Esqueleto: verificar permissão de manager -> buscar dados -> calcular ->
formatar resposta.

## 3. Comunicados
Arquivos em `announcements/templates/`:
- `AnnouncementPublisherTemplate`
- `StandardAnnouncementPublisher`
- `UrgentAnnouncementPublisher`

Esqueleto: validar segmentação (delegando à Chain de visibilidade existente) ->
formatar mensagem -> salvar -> configurar rastreamento de leitura.

### Integração
Os exemplos 2 e 3 recebem seus repositórios/chains por injeção através de
interfaces (`FinancialReportRepository`, `AnnouncementRepository` e
`AnnouncementVisibilityChain`). Isso evita duplicar infraestrutura e permite
ligar diretamente às implementações concretas já existentes no projeto.

### Testes
Foram adicionados testes unitários para os dois novos exemplos em:
- `finance/templates/financial-report.template.spec.ts`
- `announcements/templates/announcement-publisher.template.spec.ts`

O ZIP enviado contém também todos os arquivos do ZIP original, sem remover a
implementação de tickets.
